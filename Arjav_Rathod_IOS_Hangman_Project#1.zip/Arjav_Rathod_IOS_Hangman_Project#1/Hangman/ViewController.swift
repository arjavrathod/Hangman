//
//  ViewController.swift
//  Hangman
//
//  Created by Arjav Rathod on 2/20/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var Answers: [UILabel]!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet var collection:[UIButton]!
    @IBOutlet weak var winsLabel: UILabel!
    @IBOutlet weak var losesLabel: UILabel!
    var wins = UserDefaults.standard.value(forKey: "wins") as? Int ?? 0
    var loses = UserDefaults.standard.value(forKey: "loses") as? Int ?? 0
    var answer = ""
    var error = 0
    var correct = 0
    override func viewDidLoad() {
        generateAnswer()
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func generateAnswer(){
        answer = wordBank.randomElement() ?? ""
        let character = Array(answer)
        error = 0
        correct = 0
        winsLabel.text = "Wins: \(wins)"
        losesLabel.text = "Losses: \(loses)"
        image.image = UIImage(named: String(error))
        
        print(answer)
        for i in character.indices{
            Answers[i].text = String(character[i]).uppercased()
        }
        for i in Answers{
            i.textColor = .clear
        }
        for i in collection{
            i.backgroundColor = .opaqueSeparator
            i.isEnabled = true
        }
        
    }

    @IBAction func pressed_keyboard(_ sender: UIButton) {
        if(answer.lowercased().contains((sender.titleLabel?.text ?? "none").lowercased())){
            print("yes")
            sender.backgroundColor = .green
            sender.isEnabled = false
            for i in Answers{
                if((i.text?.lowercased() ?? "") == (sender.titleLabel?.text ?? "none").lowercased()){
                    print("found")
                    i.textColor = .black
                    correct += 1
                    print("correct", correct)
                    if(correct == 7){
                        wins += 1
                        UserDefaults.standard.setValue(wins, forKey: "wins")
                        let alert = UIAlertController(title: "Phew!", message: "You saved me! Would you like to play again?", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { _ in
                            self.generateAnswer()
                        }))
                        alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
            
        }
        else{
            print("no")
            sender.backgroundColor = .red
            sender.isEnabled = false
            error += 1
            print("error", error)
            image.image = UIImage(named: String(error))
            if(error == 6){
                loses += 1
                UserDefaults.standard.setValue(loses, forKey: "loses")
                let alert = UIAlertController(title: "Game Over", message: "Correct word was \(answer.capitalized). Would you like to play again?", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { _ in
                    self.generateAnswer()
                }))
                alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
}


let wordBank = ["pizzazz",
"zyzzyva",
"fuzzbox",
"pizazzy",
"jacuzzi",
"jazzman",
"jazzmen",
"jazzbos",
"jazzily",
"jazzing",
"zizzing",
"quizzed",
"zizzled",
"quizzer",
"quizzes",
"wazzock",
"zizzles",
"buzzwig",
"jazzers",
"jazzier",
"buzzcut",
"muzjiks",
"buzzing",
"buzzsaw",
"fuzzily",
"fuzzing",
"muzzily",
"schizzy",
"abbozzo",
"chazzan",
"chazzen",
"fizzily",
"fizzing",
"frizzly",
"jejunum",
"jimjams",
"jukebox",
"jumbuck",
"mezuzah",
"muzzled",
"puzzled",
"schnozz",
"wazzing",
"whizzed",
"zhuzhed",
"buzzard",
"fizzled",
"grizzly",
"guzzled",
"huzzahs",
"jujubes",
"jujuism",
"mizzled",
"muezzin",
"muzzler",
"muzzles",
"puzzler",
"puzzles",
"whizzer",
"whizzes",
"zhuzhes",
"bezique",
"bezzant",
"buzzers",
"buzzier",
"cazique",
"dizzily",
"drizzly",
"fizzles",
"frazzle",
"frizzed",
"frizzle",
"fuzzier",
"guzzler",
"guzzles",
"huzzaed",
"jezebel",
"jumpoff",
"karezza",
"mazzard",
"mezquit",
"mezuzas",
"mezuzot",
"mizzens",
"mizzles",
"muzzier",
"nuzzled",
"palazzi",
"palazzo",
"pizzles",
"sizzurp",
"skyjack",
"swizzle",
"twizzle",
"wizzens",
"zigzags",
"bezzies",
"bizzies",
"cozzies",
"dazzled"]
